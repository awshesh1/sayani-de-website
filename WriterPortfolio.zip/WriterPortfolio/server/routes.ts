import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema, insertNewsletterSubscriptionSchema } from "@shared/schema";
import { z } from "zod";
import nodemailer from 'nodemailer';

// Create email transporter
const createEmailTransporter = () => {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER || process.env.GMAIL_USER || 'sayanide1984@gmail.com',
      pass: process.env.EMAIL_PASS || process.env.GMAIL_PASS || 'demo_password'
    }
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      
      // Store message in database
      const message = await storage.createContactMessage(validatedData);
      
      // Send email notification
      try {
        const transporter = createEmailTransporter();
        
        const mailOptions = {
          from: process.env.EMAIL_USER || process.env.GMAIL_USER || 'sayanide1984@gmail.com',
          to: process.env.WRITER_EMAIL || process.env.EMAIL_USER || process.env.GMAIL_USER || 'sayanide1984@gmail.com',
          subject: `New Contact Form Message: ${validatedData.subject}`,
          html: `
            <h2>New Contact Form Submission</h2>
            <p><strong>From:</strong> ${validatedData.firstName} ${validatedData.lastName}</p>
            <p><strong>Email:</strong> ${validatedData.email}</p>
            <p><strong>Subject:</strong> ${validatedData.subject}</p>
            <p><strong>Message:</strong></p>
            <p>${validatedData.message.replace(/\n/g, '<br>')}</p>
            <hr>
            <p><small>Sent from Sayani De Author Website Contact Form</small></p>
          `
        };
        
        await transporter.sendMail(mailOptions);
        
        // Send auto-reply to sender
        const autoReplyOptions = {
          from: process.env.EMAIL_USER || process.env.GMAIL_USER || 'sayanide1984@gmail.com',
          to: validatedData.email,
          subject: 'Thank you for contacting Sayani De',
          html: `
            <h2>Thank you for your message!</h2>
            <p>Dear ${validatedData.firstName},</p>
            <p>Thank you for reaching out through my website. I've received your message and will get back to you as soon as possible.</p>
            <p>I appreciate your interest in my work and look forward to connecting with you.</p>
            <p>Best regards,<br>Sayani De</p>
            <hr>
            <p><small>This is an automated response. Please do not reply to this email.</small></p>
          `
        };
        
        await transporter.sendMail(autoReplyOptions);
        
      } catch (emailError) {
        console.error('Failed to send email:', emailError);
        // Continue even if email fails - message is still stored
      }
      
      res.json({ 
        success: true, 
        message: "Thank you for your message! I'll get back to you soon.",
        id: message.id 
      });
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Please fill in all required fields correctly.",
          errors: error.errors 
        });
      } else {
        console.error('Contact form error:', error);
        res.status(500).json({ 
          success: false, 
          message: "Sorry, there was an error sending your message. Please try again later." 
        });
      }
    }
  });

  // Newsletter subscription
  app.post("/api/newsletter", async (req, res) => {
    try {
      const validatedData = insertNewsletterSubscriptionSchema.parse(req.body);
      
      // Check if email already exists
      const existingSubscriptions = await storage.getNewsletterSubscriptions();
      const alreadySubscribed = existingSubscriptions.some(sub => sub.email === validatedData.email);
      
      if (alreadySubscribed) {
        return res.json({ 
          success: true, 
          message: "You're already subscribed to the newsletter!" 
        });
      }
      
      // Create subscription
      const subscription = await storage.createNewsletterSubscription(validatedData);
      
      // Send welcome email
      try {
        const transporter = createEmailTransporter();
        
        const mailOptions = {
          from: process.env.EMAIL_USER || process.env.GMAIL_USER || 'sayanide1984@gmail.com',
          to: validatedData.email,
          subject: 'Welcome to Sayani De\'s Newsletter',
          html: `
            <h2>Welcome to my newsletter!</h2>
            <p>Thank you for subscribing to receive updates about my latest works, writing process, and literary events.</p>
            <p>You'll be the first to know about new publications, awards, and exclusive content about my writing journey.</p>
            <p>Happy reading!</p>
            <p>Best regards,<br>Sayani De</p>
            <hr>
            <p><small>If you wish to unsubscribe at any time, please reply to this email with "UNSUBSCRIBE" in the subject line.</small></p>
          `
        };
        
        await transporter.sendMail(mailOptions);
        
      } catch (emailError) {
        console.error('Failed to send welcome email:', emailError);
      }
      
      res.json({ 
        success: true, 
        message: "Thank you for subscribing! Check your email for a welcome message.",
        id: subscription.id 
      });
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Please enter a valid email address.",
          errors: error.errors 
        });
      } else {
        console.error('Newsletter subscription error:', error);
        res.status(500).json({ 
          success: false, 
          message: "Sorry, there was an error with your subscription. Please try again later." 
        });
      }
    }
  });

  // Get contact messages (for admin use)
  app.get("/api/admin/messages", async (req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ 
        success: false, 
        message: "Error fetching messages" 
      });
    }
  });

  // Get newsletter subscriptions (for admin use)
  app.get("/api/admin/subscribers", async (req, res) => {
    try {
      const subscribers = await storage.getNewsletterSubscriptions();
      res.json(subscribers);
    } catch (error) {
      console.error('Error fetching subscribers:', error);
      res.status(500).json({ 
        success: false, 
        message: "Error fetching subscribers" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
