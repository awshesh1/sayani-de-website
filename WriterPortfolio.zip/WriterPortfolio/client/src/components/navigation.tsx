import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.offsetTop;
      const offsetPosition = elementPosition - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className="fixed top-0 w-full bg-writer-secondary/95 backdrop-blur-sm z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="font-display text-2xl font-bold text-writer-primary">
            Sayani De
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('works')}
              className="text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Works
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Contact
            </button>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-writer-primary"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </Button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-writer-secondary border-t border-writer-primary/10">
          <div className="px-4 py-4 space-y-3">
            <button 
              onClick={() => scrollToSection('home')}
              className="block text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="block text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('works')}
              className="block text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Works
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="block text-writer-primary hover:text-writer-accent transition-colors duration-300"
            >
              Contact
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
