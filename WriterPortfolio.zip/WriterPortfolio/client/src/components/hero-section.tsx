import { Button } from "@/components/ui/button";
import { Twitter, Instagram, Linkedin } from "lucide-react";
import { FaGoodreads } from "react-icons/fa";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.offsetTop;
      const offsetPosition = elementPosition - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="pt-20 pb-16 bg-gradient-to-br from-writer-secondary to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h1 className="font-display text-4xl md:text-6xl font-bold text-writer-primary mb-6 leading-tight">
              Stories of Identity &{" "}
              <span className="text-writer-accent">Connection</span>
            </h1>
            <p className="text-lg md:text-xl text-writer-muted mb-8 leading-relaxed">
              Upcoming author of contemporary fiction exploring themes of identity, culture, and human connection.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => scrollToSection('works')}
                className="bg-writer-primary text-white px-8 py-3 rounded-full hover:bg-writer-primary/90 transition-colors duration-300 font-medium"
              >
                Explore My Works
              </Button>
              <Button 
                variant="outline"
                onClick={() => scrollToSection('contact')}
                className="border-2 border-writer-accent text-writer-accent px-8 py-3 rounded-full hover:bg-writer-accent hover:text-white transition-colors duration-300 font-medium"
              >
                Get In Touch
              </Button>
            </div>
            
            {/* Social Media Links */}
            <div className="flex space-x-4 mt-8">
              <a 
                href="https://twitter.com/sayanide" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-writer-muted hover:text-writer-accent transition-colors duration-300"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="https://instagram.com/sayanide" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-writer-muted hover:text-writer-accent transition-colors duration-300"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="https://linkedin.com/in/sayanide" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-writer-muted hover:text-writer-accent transition-colors duration-300"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="https://goodreads.com/author/show/sayanide" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-writer-muted hover:text-writer-accent transition-colors duration-300"
              >
                <FaGoodreads size={20} />
              </a>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <img 
              src="/sayani-portrait.jpg"
              alt="Sayani De - Professional author portrait" 
              className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
