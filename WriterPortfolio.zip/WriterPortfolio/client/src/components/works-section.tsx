import { Card, CardContent } from "@/components/ui/card";
import { Star, ExternalLink } from "lucide-react";

interface Book {
  id: number;
  title: string;
  year: string;
  genre: string;
  description: string;
  rating: number;
  coverImage: string;
  isUpcoming?: boolean;
  readMoreUrl?: string;
}

const books: Book[] = [
  {
    id: 1,
    title: "The Lasts of Her",
    year: "2024",
    genre: "Short Story - The Bangalore Review",
    description: "A poignant story about family, memory, and the weight of cultural traditions. Explores the relationship between a granddaughter and her aging grandmother, touching on themes of displacement, belonging, and the gradual loss of home.",
    rating: 4.8,
    coverImage: "https://bangalorereview.com/wp-content/uploads/2024/10/rod-long-y0OAmd_COUM-unsplash.jpg",
    readMoreUrl: "https://bangalorereview.com/2024/10/the-lasts-of-her/"
  },
  {
    id: 2,
    title: "Published in The Sahitya Akademi Magazine",
    year: "2024",
    genre: "Literary Fiction",
    description: "Featured in the prestigious Sahitya Akademi Magazine, India's national academy of letters. A powerful narrative exploring themes of identity and cultural heritage.",
    rating: 4.7,
    coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=600",
    readMoreUrl: "https://drive.google.com/file/d/11dgAuTh-rti6yzrE_7hR-sU2VW3bz6_Y/view?usp=sharing"
  },
  {
    id: 3,
    title: "Mismatched",
    year: "2024",
    genre: "Short Story - The Indian Review",
    description: "A powerful story exploring family dynamics, secrets, and the complexities of relationships. Featured as Editor's Choice, it delves into themes of marriage, control, and hidden truths across generations.",
    rating: 4.6,
    coverImage: "https://indianreview.in/wp-content/uploads/2024/02/Mismatched-Sayani-De.webp",
    readMoreUrl: "https://indianreview.in/fiction/mismatched-sayani-de/"
  },
  {
    id: 4,
    title: "Anu Didi",
    year: "2023",
    genre: "Literary Fiction - Muse India",
    description: "A powerful story about acceptance, dignity, and social inclusion featuring a transgender character in rural West Bengal. Published in Muse India's May-June 2023 issue, it explores themes of gender identity, family bonds, and the quest for belonging.",
    rating: 4.8,
    coverImage: "http://www.museindia.com/conimg/10637.jpg",
    readMoreUrl: "https://museindia.com/Home/ViewContentData?arttype=fiction&issid=109&menuid=10637"
  },
  {
    id: 5,
    title: "The Selkie (UK) Anthology",
    year: "2024",
    genre: "Literary Fiction",
    description: "An intimate story of migration and memory, featured in this prestigious UK anthology collection.",
    rating: 4.5,
    coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=600"
  },
  {
    id: 6,
    title: "Commonwealth Short Story Prize Longlisted (Unpublished)",
    year: "2025",
    genre: "Short Story - Longlisted",
    description: "Longlisted for the prestigious Commonwealth Short Story Prize 2025. This unpublished work showcases exceptional storytelling that bridges cultural divides and explores universal themes of human connection.",
    rating: 4.9,
    coverImage: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=600",
    readMoreUrl: "https://drive.google.com/file/d/1U_ras1SzXcYjgSMaNJwTAzAGfzyispaF/view?usp=sharing"
  },
  {
    id: 7,
    title: "Upcoming Novel",
    year: "2025",
    genre: "Contemporary Fiction",
    description: "Currently working on a novel exploring themes of identity, culture, and belonging in our interconnected world.",
    rating: 0,
    coverImage: "https://images.unsplash.com/photo-1455390582262-044cdead277a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=600",
    isUpcoming: true
  }
];

export default function WorksSection() {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} size={12} className="fill-yellow-400 text-yellow-400" />);
    }
    
    if (hasHalfStar) {
      stars.push(<Star key="half" size={12} className="fill-yellow-200 text-yellow-400" />);
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} size={12} className="text-gray-300" />);
    }
    
    return stars;
  };

  return (
    <section id="works" className="py-20 bg-writer-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-writer-primary mb-4">Published Works</h2>
          <div className="w-24 h-1 bg-writer-accent mx-auto mb-6"></div>
          <p className="text-lg text-writer-muted max-w-3xl mx-auto">
            Explore my collection of contemporary fiction novels, each crafted to delve deep into the human experience and contemporary relationships.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {books.map((book) => (
            <Card key={book.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <img 
                src={book.coverImage} 
                alt={`Book cover - ${book.title}`} 
                className="w-full h-64 object-cover"
              />
              
              <CardContent className="p-6">
                <h3 className="font-display text-xl font-bold text-writer-primary mb-2">{book.title}</h3>
                <p className="text-sm text-writer-accent mb-3">
                  Published {book.year} • {book.genre}
                </p>
                <p className="text-writer-muted mb-4 text-sm leading-relaxed">
                  {book.description}
                </p>
                <div className="flex items-center justify-between">
                  {book.isUpcoming ? (
                    <span className="text-xs text-writer-muted">Work in Progress</span>
                  ) : (
                    <div className="flex items-center space-x-1">
                      {renderStars(book.rating)}
                      <span className="text-xs text-writer-muted ml-1">{book.rating}/5</span>
                    </div>
                  )}
                  {book.readMoreUrl ? (
                    <a 
                      href={book.readMoreUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-writer-accent hover:text-writer-primary transition-colors duration-300 text-xs font-medium flex items-center space-x-1"
                    >
                      <span>Read Story</span>
                      <ExternalLink size={12} />
                    </a>
                  ) : (
                    <button className="text-writer-accent hover:text-writer-primary transition-colors duration-300 text-xs font-medium flex items-center space-x-1">
                      <span>{book.isUpcoming ? "Updates Soon" : "Learn More"}</span>
                      <ExternalLink size={12} />
                    </button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Featured Quote/Excerpt */}
        <div className="mt-16 text-center">
          <div className="max-w-4xl mx-auto bg-white rounded-2xl p-8 shadow-lg">
            <blockquote className="font-accent italic text-xl md:text-2xl text-writer-primary mb-4">
              "In the spaces between cultures, between languages, between what we were and what we're becoming, we find the most honest stories about who we really are."
            </blockquote>
            <cite className="text-writer-accent font-medium">— From Sayani's writing on identity and belonging</cite>
          </div>
        </div>
      </div>
    </section>
  );
}
