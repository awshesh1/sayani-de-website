import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowRight } from "lucide-react";

export default function Footer() {
  const { toast } = useToast();
  const [newsletterEmail, setNewsletterEmail] = useState("");

  const newsletterMutation = useMutation({
    mutationFn: async (email: string) => {
      return apiRequest("POST", "/api/newsletter", { email });
    },
    onSuccess: () => {
      toast({
        title: "Successfully subscribed!",
        description: "Thank you for subscribing to my newsletter.",
      });
      setNewsletterEmail("");
    },
    onError: (error: any) => {
      toast({
        title: "Subscription error",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.offsetTop;
      const offsetPosition = elementPosition - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail && newsletterEmail.includes('@')) {
      newsletterMutation.mutate(newsletterEmail);
    } else {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
    }
  };

  return (
    <footer className="bg-writer-primary text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-display text-2xl font-bold mb-4">Sayani De</h3>
            <p className="text-gray-300">
              Upcoming author of contemporary fiction exploring themes of identity, culture, and human connection.
            </p>
          </div>
          
          <div>
            <h4 className="font-display text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('about')}
                  className="text-gray-300 hover:text-writer-accent transition-colors duration-300"
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('works')}
                  className="text-gray-300 hover:text-writer-accent transition-colors duration-300"
                >
                  Works
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="text-gray-300 hover:text-writer-accent transition-colors duration-300"
                >
                  Contact
                </button>
              </li>
              <li>
                <a 
                  href="/press-kit" 
                  className="text-gray-300 hover:text-writer-accent transition-colors duration-300"
                >
                  Press Kit
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display text-lg font-bold mb-4">Newsletter</h4>
            <p className="text-gray-300 mb-4 text-sm">Get updates on new releases and literary events.</p>
            <form onSubmit={handleNewsletterSubmit} className="flex">
              <Input 
                type="email" 
                placeholder="Your email" 
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 rounded-l-lg rounded-r-none text-writer-primary border-r-0"
              />
              <Button 
                type="submit"
                disabled={newsletterMutation.isPending}
                className="bg-writer-accent text-writer-primary px-4 py-2 rounded-r-lg rounded-l-none hover:bg-writer-accent/90 transition-colors duration-300"
              >
                {newsletterMutation.isPending ? "..." : <ArrowRight size={16} />}
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-600 mt-8 pt-8 text-center">
          <p className="text-gray-300 text-sm">
            © 2024 Sayani De. All rights reserved. | Website designed for literary excellence.
          </p>
        </div>
      </div>
    </footer>
  );
}
