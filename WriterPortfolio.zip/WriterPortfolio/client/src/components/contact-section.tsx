import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Mail, Phone, MapPin } from "lucide-react";
import { Twitter, Instagram, Linkedin, Facebook } from "lucide-react";

const contactFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  subject: z.string().min(1, "Please select a subject"),
  message: z.string().min(10, "Message must be at least 10 characters long"),
});

const newsletterSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type ContactFormData = z.infer<typeof contactFormSchema>;
type NewsletterData = z.infer<typeof newsletterSchema>;

export default function ContactSection() {
  const { toast } = useToast();
  const [newsletterEmail, setNewsletterEmail] = useState("");

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error sending message",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const newsletterMutation = useMutation({
    mutationFn: async (data: NewsletterData) => {
      return apiRequest("POST", "/api/newsletter", data);
    },
    onSuccess: () => {
      toast({
        title: "Successfully subscribed!",
        description: "Thank you for subscribing to my newsletter.",
      });
      setNewsletterEmail("");
    },
    onError: (error: any) => {
      toast({
        title: "Subscription error",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail && newsletterEmail.includes('@')) {
      newsletterMutation.mutate({ email: newsletterEmail });
    } else {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
    }
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-white to-writer-secondary">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-writer-primary mb-4">Let's Connect</h2>
          <div className="w-24 h-1 bg-writer-accent mx-auto mb-6"></div>
          <p className="text-lg text-writer-muted max-w-3xl mx-auto">
            Whether you're a reader, fellow writer, or potential collaborator, I'd love to hear from you. Drop me a line and let's start a conversation.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-white rounded-xl shadow-lg">
            <CardContent className="p-8">
              <h3 className="font-display text-2xl font-bold text-writer-primary mb-6">Send a Message</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-writer-primary">First Name</FormLabel>
                          <FormControl>
                            <Input {...field} className="rounded-lg border-gray-300 focus:ring-writer-accent focus:border-transparent" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-writer-primary">Last Name</FormLabel>
                          <FormControl>
                            <Input {...field} className="rounded-lg border-gray-300 focus:ring-writer-accent focus:border-transparent" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-writer-primary">Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} className="rounded-lg border-gray-300 focus:ring-writer-accent focus:border-transparent" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-writer-primary">Subject</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="rounded-lg border-gray-300 focus:ring-writer-accent focus:border-transparent">
                              <SelectValue placeholder="Select a topic..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="general">General Inquiry</SelectItem>
                            <SelectItem value="media">Media/Interview Request</SelectItem>
                            <SelectItem value="collaboration">Collaboration Opportunity</SelectItem>
                            <SelectItem value="book-club">Book Club Discussion</SelectItem>
                            <SelectItem value="speaking">Speaking Engagement</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-writer-primary">Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            rows={5} 
                            placeholder="Tell me about your inquiry..."
                            className="rounded-lg border-gray-300 focus:ring-writer-accent focus:border-transparent resize-none"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    disabled={contactMutation.isPending}
                    className="w-full bg-writer-primary text-white py-3 px-6 rounded-lg hover:bg-writer-primary/90 transition-colors duration-300 font-medium"
                  >
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          {/* Contact Info & Social */}
          <div className="space-y-8">
            <Card className="bg-white rounded-xl shadow-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400" 
                alt="Cozy literary workspace with books and writing materials" 
                className="w-full h-48 object-cover"
              />
              
              <CardContent className="p-6">
                <h4 className="font-display text-xl font-bold text-writer-primary mb-4">Other Ways to Connect</h4>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="text-writer-accent" size={18} />
                    <span className="text-writer-muted">sayanide1984@gmail.com</span>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Phone className="text-writer-accent" size={18} />
                    <span className="text-writer-muted">Available through email</span>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <MapPin className="text-writer-accent" size={18} />
                    <span className="text-writer-muted">Bangalore, India</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Social Media */}
            <Card className="bg-white rounded-xl shadow-lg">
              <CardContent className="p-6">
                <h4 className="font-display text-xl font-bold text-writer-primary mb-4">Follow My Journey</h4>
                <p className="text-writer-muted mb-6">Stay updated on new releases, writing process insights, and literary events.</p>
                
                <div className="grid grid-cols-2 gap-4">
                  <a 
                    href="https://x.com/tweets_shay" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2 bg-blue-50 text-blue-600 py-3 px-4 rounded-lg hover:bg-blue-100 transition-colors duration-300"
                  >
                    <Twitter size={18} />
                    <span className="font-medium">Twitter</span>
                  </a>
                  
                  <a 
                    href="https://www.instagram.com/sayani_quill/" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2 bg-pink-50 text-pink-600 py-3 px-4 rounded-lg hover:bg-pink-100 transition-colors duration-300"
                  >
                    <Instagram size={18} />
                    <span className="font-medium">Instagram</span>
                  </a>
                  
                  <a 
                    href="https://www.linkedin.com/in/sayanide" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2 bg-blue-50 text-blue-800 py-3 px-4 rounded-lg hover:bg-blue-100 transition-colors duration-300"
                  >
                    <Linkedin size={18} />
                    <span className="font-medium">LinkedIn</span>
                  </a>
                  
                  <a 
                    href="https://www.facebook.com/sayani.de.3" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2 bg-blue-50 text-blue-700 py-3 px-4 rounded-lg hover:bg-blue-100 transition-colors duration-300"
                  >
                    <Facebook size={18} />
                    <span className="font-medium">Facebook</span>
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
