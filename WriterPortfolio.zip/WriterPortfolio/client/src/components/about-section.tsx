export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-writer-primary mb-4">About Sayani</h2>
          <div className="w-24 h-1 bg-writer-accent mx-auto"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1542435503-956c469947f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Writer working at desk with notebook and laptop" 
              className="rounded-xl shadow-lg w-full"
            />
          </div>
          
          <div>
            <blockquote className="font-accent italic text-xl text-writer-primary mb-6 border-l-4 border-writer-accent pl-6">
              "Stories have the power to bridge cultures and connect hearts. I write to explore the beautiful complexity of identity and belonging in our interconnected world."
            </blockquote>
            
            <div className="prose prose-lg text-writer-muted">
              <p className="mb-4">
                Sayani is a bibliophile, compulsive traveler, and sustainability enthusiast. Her work has been longlisted for Commonwealth short story prize 2025 and has featured in The Bangalore Review, Muse India, The Selkie (UK) anthology, Indian Review, Borderless Journal, Mysticeti, Mean Pepper Vine, Women's Web, won a contest at Story Mirror.
              </p>
              <p className="mb-4">
                Her contemporary fiction explores themes of identity, culture, and human connection, drawing from her experiences as a traveler and her deep love for literature. Through her writing, she seeks to create narratives that resonate across cultural boundaries.
              </p>
              <p>
                She currently lives in Bangalore, India, where she finds inspiration in the city's vibrant literary community and diverse cultural landscape.
              </p>
            </div>
            
            {/* Awards/Recognition */}
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-writer-secondary rounded-lg">
                <div className="font-display text-2xl font-bold text-writer-accent">2025</div>
                <div className="text-sm text-writer-muted">Commonwealth Longlisted</div>
              </div>
              <div className="text-center p-4 bg-writer-secondary rounded-lg">
                <div className="font-display text-2xl font-bold text-writer-accent">9+</div>
                <div className="text-sm text-writer-muted">Publications</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
