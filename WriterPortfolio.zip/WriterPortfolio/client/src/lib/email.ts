// Email utility functions for frontend
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const formatEmailSubject = (subject: string): string => {
  const subjectMap: Record<string, string> = {
    general: "General Inquiry",
    media: "Media/Interview Request",
    collaboration: "Collaboration Opportunity",
    "book-club": "Book Club Discussion",
    speaking: "Speaking Engagement",
  };
  
  return subjectMap[subject] || subject;
};

export const sanitizeMessage = (message: string): string => {
  return message.trim().replace(/\s+/g, ' ');
};
